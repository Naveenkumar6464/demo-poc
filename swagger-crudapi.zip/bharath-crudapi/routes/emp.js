const express = require('express')
const router = express()
const { create, view, getById, update, remove, exportUser } = require('../controller/emp')
const bodyparser = require('body-parser');
// const { exportUser } = require('../controller/emp')


router.use(bodyparser.json())

/** 
 * @swagger 
 * components:
 *   schemas:
 *     Post:
 *       type: object
 *       required:
 *         - empName
 *         - empEmail
 *         - empMobile
 *       properties:
 *         empName:
 *           type: string
 *         empEmail:
 *           type: string
 *         empMobile:
 *           type: string
 *       example:
 *         empName: Bharathkumar
 *         empEmail: bk@gmail.com
 *         empMobile: 8989890898
 *
 */

/**
 * @swagger
 *  tags:
 *    name: Posts
 *    description: posts of users
 */


/**
 * @swagger
 * /emp/create:
 *   post:
 *     summary: Create a new post
 *     tags: [create]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Post'
 *     responses:
 *       200:
 *         description: The post was successfully created
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Post'
 *       401:
 *         description: Unauthorized
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/responses/Unauthorized'
 *       500:
 *         description: Some Sever Error
 */

// router.post('/create', create)

/**
 * @swagger
 * /emp/view:
 *   get:
 *     summary: Returns all posts
 *     tags: [Posts]
 *     responses:
 *       200:
 *         description: the list of the posts
 * 
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Post'
 */
router.post('/create', create)
router.get('/view', view)
router.get('/:id', getById)
router.patch('/update', update)
router.delete('/:id', remove)
// router.get("/downloadxl", exportUser)




module.exports = router;