const Emp = require('../models/emp');
const User = require('../models/users');
const excelJS = require('exceljs');


const create = (req, res, next) => {
    try {
        let empName = req.body.empName;
        let empEmail = req.body.empEmail;
        let empMobile = req.body.empMobile;

        let emp = new Emp({
            empName,
            empEmail,
            empMobile
        })
        emp.save().then((data) => {
            res.status(401).send(data)
        })
    } catch (err) {
        return res.status(500).send(err);

    }
}
const view = (req, res, next) => {
    Emp.find({}).then((data) => {
        res.send(data)
    })
}
const getById = (req, res, next) => {
    Emp.findById(req.params.id).then((data) => {
        res.send(data)
    })
}
const update = (req, res, next) => {

    Emp.findOneAndUpdate({ "empName": req.body.empName }, { $set: { "empEmail": req.body.empEmail } }).then((data) => {
        res.send(data)
        console.log(req.body.empName);
    })
}
const remove = (req, res, next) => {
    Emp.findByIdAndDelete(req.params.id).then((data) => {
        res.send(data)
    })
}





const exportUser = async (req, res) => {
    const workbook = new excelJS.Workbook();
    const worksheet = workbook.addWorksheet("My Users");
    const path = "./files";
    worksheet.columns = [
        { header: "S no", key: "S_no", width: 10 },
        { header: "UserName", key: "userName", width: 10 },
        { header: "Email", key: "email", width: 20 },
        { header: "Age", key: "age", width: 10 }
    ];

    let counter = 1;
    User.forEach((user) => {
        user.S_no = counter;
        worksheet.addRow(user);
        counter++;
    });
    worksheet.getRow(1).eachCell((cell) => {
        cell.font = { bold: true };
    });
    try {
        res.setHeader(
            "Content-Type",
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        );
        res.setHeader("Content-Disposition", `attachment; filename=users.xlsx`);

        return workbook.xlsx.write(res).then(() => {
            res.status(200);
        });
        // const data = await workbook.xlsx.writeFile(`${path}/users.xlsx`)
        //     .then(() => {
        //         console.log(data);
        //         res.send({
        //             status: "success",
        //             message: "file successfully downloaded",
        //             path: `${path}/users.xlsx`,
        //         });
        //     });
    } catch (err) {
        res.send({
            status: "error",
            message: "Something went wrong",
        });
    }
};




module.exports = {
    create,
    view,
    getById,
    update,
    remove,
    exportUser
}
