const User = [
    {
        userName: "Bharath",
        email: "bharath@gmail.com",
        age: "21"
    },
    {
        userName: "Kumar",
        email: "kumar@gmail.com",
        age: "21"
    },
    {
        userName: "Surya",
        email: "surya@gmail.com",
        age: "21"
    },
    {
        userName: "Darun",
        email: "darun@gmail.com",
        age: "21"
    },
    {
        userName: "Surendar",
        email: "surendar@gmail.com",
        age: "24"
    },
    {
        userName: "Praveen",
        email: "praveen@gmail.com",
        age: "22"
    },

];


module.exports = User;