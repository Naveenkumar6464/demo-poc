const express = require("express");
const router = express.Router();
const userController = require("../../controller/user.controller.js");
const auth = require("../../middleware/auth");
const validate = require("../../middleware/validate");
const userValidation = require("../../validations/user.validation");

router
  .route("/")
  .post( validate(userValidation.createUser), userController.signUp)
  .get(
    validate(userValidation.getUsers),
    userController.getAllUsers
  );

router
  .route("/:id")
  .get(
    validate(userValidation.getUser),
    userController.getUserById
  )
  .patch(
    validate(userValidation.updateUser),
    userController.updateUser
  )
  .delete(
    validate(userValidation.deleteUser),
    userController.deleteUser
  );

module.exports = router;


/**
 * @swagger
 * tags:
 *   name: Users
 *   description: User management and retrieval
 */




/**
 * @swagger
 * tags:
 *   name: Users
 *   description: Register and login
 */

/**
 * @swagger
 *  /user:
 *    post:
 *      summary: Create a user
 *      description: Only admins can create other users.
 *      tags: [Users]
 *      requestBody:
 *        required: true
 *        content:
 *          application/json:
 *            schema:
 *              type: object
 *              required:
 *                - email
 *                - password
 *                - firstName
 *                - lastName
 *                - role
 *              properties:
 *                first_name:
 *                  type: string
 *                last_name:
 *                  type: string  # Added space here
 *                email:
 *                  type: string
 *                  format: email
 *                  description: must be unique
 *                password:
 *                  type: string
 *                  format: password
 *                  minLength: 8
 *                  description: At least one number and one letter
 *                role:
 *                  type: string        
 *              example:
 *                first_name: naveen
 *                last_name: kumar
 *                email: naveen@example.com
 *                password: password1
 *                role: user
 *      responses:
 *        "201":
 *          description: Created
 *          content:
 *            application/json:
 *              schema:
 *                type: object
 *                properties:
 *                  user:
 *                    $ref: '#/components/schemas/User'
 *        "400":
 *          $ref: '#/components/responses/DuplicateEmail'
*    get:
 *      summary: Get all users
 *      description: Only admins can retrieve all users.
 *      tags: [Users]
 *      security:
 *        - bearerAuth: []
 *      parameters:
 *        - in: query
 *          name: name
 *          schema:
 *            type: string
 *          description: User name
 *        - in: query
 *          name: role
 *          schema:
 *            type: string
 *          description: User role
 *        - in: query
 *          name: sortBy
 *          schema:
 *            type: string
 *          description: sort by query in the form of field:desc/asc (ex. name:asc)
 *        - in: query
 *          name: limit
 *          schema:
 *            type: integer
 *            minimum: 1
 *          default: 10
 *          description: Maximum number of users
 *        - in: query
 *          name: page
 *          schema:
 *            type: integer
 *            minimum: 1
 *            default: 1
 *          description: Page number
 *      responses:
 *        "200":
 *          description: Successful operation
 *          content:
 *            application/json:
 *              schema:
 *                type: array
 *                items:
 *                  $ref: '#/components/schemas/User'
 *        "401":
 *          description: Unauthorized - Invalid token
 *        "403":
 *          description: Forbidden - User not authorized
 *        "404":
 *          description: Not found - Users not found
 */


/**
 * @swagger
 * /user/{id}:
 *   get:
 *     summary: Get a user
 *     description: Logged in users can fetch only their own user information. Only admins can fetch other users.
 *     tags: [Users]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: User id
 *     responses:
 *       "200":
 *         description: Successful operation
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/User'
 *       "401":
 *         description: Unauthorized - Invalid token
 *       "403":
 *         description: Forbidden - User not authorized
 *       "404":
 *         description: Not found - User not found
 *
 *   patch:
 *     summary: Update a user
 *     description: Logged in users can only update their own information. Only admins can update other users.
 *     tags: [Users]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: User id
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               first_name:
 *                 type: string
 *               last_name:
 *                 type: string
 *               email:
 *                 type: string
 *                 format: email
 *                 description: must be unique
 *               password:
 *                 type: string
 *                 format: password
 *                 minLength: 8
 *                 description: At least one number and one letter
 *             example:
 *               first_name: fake name
 *               last_name: fake name
 *               email: fake@example.com
 *               password: password1
 *     responses:
 *       "200":
 *         description: Successful operation
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/User'
 *       "400":
 *         description: Bad request - Invalid data provided
 *       "401":
 *         description: Unauthorized - Invalid token
 *       "403":
 *         description: Forbidden - User not authorized
 *       "404":
 *         description: Not found - User not found
 *
 *   delete:
 *     summary: Delete a user
 *     description: Logged in users can delete only themselves. Only admins can delete other users.
 *     tags: [Users]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: User id
 *     responses:
 *       "204":
 *         description: Successful operation - No content
 *       "401":
 *         description: Unauthorized - Invalid token
 *       "403":
 *         description: Forbidden - User not authorized
 *       "404":
 *         description: Not found - User not found
 */


