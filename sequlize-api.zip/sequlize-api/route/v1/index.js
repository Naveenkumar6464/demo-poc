const express = require("express");

const userRoute = require("./user.route");
const helloRoute = require("./hello.route");

const router = express.Router();

// API V1 Routes
router.use("/", helloRoute);
router.use("/user", userRoute);

module.exports = router;
